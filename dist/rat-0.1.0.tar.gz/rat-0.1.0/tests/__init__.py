"""Tests for RAT package."""
